# instagram
copy instagram webpage
2016.08.18创建项目，并仿写index.html实现网页静态效果。
