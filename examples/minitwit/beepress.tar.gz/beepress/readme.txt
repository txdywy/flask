=== BeePress-微信文章采集 ===
Contributors: AlwaysBee, hi@sk8.tech 
Tags: 微信公众号文章采集, 微信采集历史文章, 微信公众号文章导入, 公众号文章自动采集, 微信公众号文章, 文章导入插件, 批量导入公众号文章
Donate link: http://artizen.me/
Author URI: http://artizen.me/
Plugin URI: http://artizen.me/beepress
Stable tag: 2.3.2
Requires at least: 3.5
Tested up to: 4.8.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

英文:BeePress is an awesome plugin which can help you import the articles written in WeChat Official Accounts

Chinese：BeePress 是一款能够帮助你导入微信公众号文章的插件，可以实现单篇或者批量导入微信文章、自动同步文章、采集指定公众号所有历史文章，支持将图片资源保存到本地

== Description ==

英文: BeePress is an awesome plugin which can help you import the articles written in WeChat Official Accounts

Chinese：在自媒体盛行的年代，我们同时在多个平台进行内容创作，但是由于平台之间的差异，当我们需要把另一个平台的内容转移到其他平台时，我们的工作量会增大，而 BeePress 的存在就是为了方便用户能够将微信公众号的文章导入到自己的 WordPress 网站中，支持单篇和批量文章导入、自动同步、采集指定公众号历史文章、自动选取特色图等功能，只需要将文章地址复制到输入款中，点击确认即可一键导入，同时支持将公众号的文章保存到本地，避免出现文章因为防盗链的问题无法显示。更多资料请访问<a href="http://artizen.me/beepress">BeePress官方地址<a/>

== Installation ==
1. Download zip file
2. Upload the BeePress plugin to your blog
3. Activate it
More Detail: Please visit the<a href="http://artizen.me/beepress"> official site<a/>
安装：
1. 在插件后台搜索 BeePress 安装启用即可
更多详情请访问<a href="http://artizen.me/beepress">BeePress官方地址<a/>

== Frequently Asked Questions ==
<h2>速度慢</h2>
请确保您的博客所在服务器网络状况良好，批量导入不宜导入太多文章
<h2>无法导入</h2>
可能是网络状况不好或者你的PHP版本问题，推荐PHP5.3及以上版本

More Detail: Please visit the<a href="http://artizen.me/beepress"> official site<a/>
更多详情请访问<a href="http://artizen.me/beepress">BeePress官方地址<a/>

== Screenshots ==
None
== Changelog ==
= 2.3.2 =
* 增加强制导入文章功能
* 导入单篇文章后跳转到文章编辑界面
* 去除最后一张无效图片
* 修复上一版本改动造成的特色图设置不成功的问题
= 2.3.1 =
* 修复版权信息无法添加
= 2.3.0 =
* 过滤重复文章
* 版权信息更改
= 2.2.0 =
* 界面更新
* 去除作者选项，默认就是当前登陆用户
* 增加采集历史文章说明
= 2.1.1 =
* 修复低版本（PHP5.4前)报错的问题，语法不兼容
* 增加侧边栏的阿里云推广链接
= 2.1.0 =
* 去除无关属性
* 设置特色图片
= 2.0.1 =
* 修复乱码的问题
= 2.0.0 =
* 增加自动采集功能
= 1.5.0 =
* 增加权限控制，使得有编辑文章的用户可以使用BeePress
= 1.4.1 =
* 增加curl方式获取内容
= 1.4.0 =
* 增加调试信息
= 1.3.0 =
* 增加图片路径保存选择，提供绝对路径和相对路径
= 1.2.0 =
* 提高图片下载质量
= 1.1.2 =
* 向下支持PHP5.3以下版本 
* 体验优化
= 1.1.1 =
* 修复部分图片出现防盗链的问题
= 1.1.0 =
* 增加文章类型选项
= 1.0.1 =
* 解决从搜狗复制的链接无法导入的问题
* 增加去除原文样式
* 增加分类目录选择

== Upgrade Notice ==

